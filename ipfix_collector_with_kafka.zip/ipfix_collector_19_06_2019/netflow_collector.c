/*  Collector listens to netflow traffic on the default port 2055
    to collect the required netflow fields from the data record. */

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <signal.h>
#include <libgen.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <pthread.h> 

#include "ipfix.h"
#include "ipfix_col.h"
#include "ipfix_def_fokus.h"
#include "ipfix_fields_fokus.h"
#include "json_parser.h"
#include "build_and_xmit_protobuf.h"
#include "timer.h"
#include "mpoll.h"
#include "rdkafka_simple_producer_test.h"

#define NETFLOW_PORT    2055
#define MAX_CONNECTION  10

/*------ global variable ---------------------------------------------------------*/

int *udp_s1 = NULL, nudp_s1 = 0;   /* For netflow packets */
int g_flow_count = 0, match_field_count = 0, collect_field_count = 0;

nf_data_to_match_and_collect_t nf_data;

static ipfix_col_info_t *g_colinfo = NULL; 

void exit_func ( int signo )
{
    if ( udp_s1 ) {
        int i;

        for( i = 0; i < nudp_s1; i++)
            close( udp_s1[i] );
    }
    printf("flow_count = %d\n", g_flow_count);

    ipfix_col_cleanup();
    ipfix_cleanup();
    sleep(15);
    kafka_stop();
    exit( 1 );
}

/* Check whether the IP flow match the seven tuple and its value */
/* If matched, collect the required field values from the IP flow otherwise dropped the flow */
int match_and_collect(ipfixt_node_t* tmpl, ipfix_datarecord_t* data)
{
    int  template_number_record[tmpl->ipfixt->nfields];
    char data_record[tmpl->ipfixt->nfields][MAX_CHARACTERS];
    
    int i,j;
    int greater_count = 0;
    bool match_flag,collect_flag;

    collected_fields_and_values_t *col_data;
    col_data = (collected_fields_and_values_t*)malloc(MAX_NO_OF_FIELDS_TO_COLLECT * sizeof(collected_fields_and_values_t));

    /* Initially make all the important data as 0 or NULL to avoid garbage values */
    memset( col_data, 0, sizeof(collected_fields_and_values_t) );
    memset( template_number_record, 0, sizeof(template_number_record));
    memset( data_record, 0, sizeof(data_record));

    /* Getting the template and data value */
    for ( i = 0; i < tmpl->ipfixt->nfields; i++ ) {
        template_number_record[i] = tmpl->ipfixt->fields[i].elem->ft->ftype;
        tmpl->ipfixt->fields[i].elem->snprint( data_record[i], 
                                            sizeof(data_record[i]), 
                                            data->addrs[i], 
                                            data->lens[i] ); /* snprint will give the data in the string format */
    }

    g_flow_count++;
    greater_count = (match_field_count > collect_field_count) ? match_field_count: collect_field_count;
    /* Match and collect the required field values from the IP flow */
    for( i = 0 ; i < greater_count ; i++ ) {
        strcpy( col_data->collected_field_names[i], nf_data.netflow_field_name_to_collect[i] );

        match_flag   = ( i < match_field_count )   ? FALSE : TRUE;
        collect_flag = ( i < collect_field_count ) ? FALSE : TRUE;

        for( j = 0; (j < tmpl->ipfixt->nfields) && ( 0 == (collect_flag && match_flag) ); j++ ) {
            if( FALSE == match_flag ){
                if( nf_data.netflow_field_number_to_match[i] == template_number_record[j] && ( ! strcmp( nf_data.netflow_field_values_to_match[i], data_record[j]) ) ){
                    match_flag = TRUE;
                    continue;
                }
            }
            
            if( FALSE == collect_flag ) {
                if( nf_data.netflow_field_number_to_collect[i] == template_number_record[j] ){
                    strcpy( col_data->collected_field_values[i], data_record[j]);
                    collect_flag = TRUE;
                    continue;
                }
            }
        }

        // Empty string and null string are not supported in protobuf packing
        // When the required collected field and its value are not present in the flow, assign "NULL" to that value. 
        if(collect_flag == FALSE)
            strcpy( col_data->collected_field_values[i], "NULL");

        /* Flow dropped when match fails */
        if( (FALSE == match_flag ) && (i < match_field_count) ) {
            printf("\nIP Flow dropped\n"); 
            free(col_data);       
            return 0;
        }   
    }
   
    build_protobuf(col_data,collect_field_count);
    return 0;
}
  
/* check whether the template is option or data template */
/* If data template, match and collect the required fields from the ip flow */
/* If option template, */
int ipfix_collector( ipfixs_node_t* s, ipfixt_node_t* template,
                          ipfix_datarecord_t* data, void* args)
{ 
    
    switch(template->ipfixt->type) {
        case DATA_TEMPLATE   : match_and_collect(template,data);
                               break;

        case OPTION_TEMPLATE : printf("\nThis is option template ");
                               break;

        default              : printf("\n error in template_type ");
        					   break;
    }

    return 0;   
}

/* Initialization of ipfix collector */
int ipfix_collector_init() 
{

    if ( g_colinfo ) {
        errno = EAGAIN;
        return -1; 
    }

    if ( (g_colinfo = calloc( 1, sizeof(ipfix_col_info_t))) ==NULL) {
        return -1;
    }
    /* Register ipfix collector function to the export_drecord() pointer */
    /* Make all other function pointer as NULL to avoid the file writing */

    g_colinfo->export_newsource = NULL;
    g_colinfo->export_newmsg    = NULL;
    g_colinfo->export_trecord   = NULL;
    g_colinfo->export_drecord   = ipfix_collector; /* This will export option template as well as data template and its respective data records */
    g_colinfo->export_cleanup   = NULL;
    g_colinfo->data = NULL;

    return ipfix_col_register_export( g_colinfo );
}

/*------ main ------------------------------------------------------------*/

int main (int argc, char *argv[])
{
    /* Initialize the timer */
    //if( timer_init() < 0 )
    //    printf("\n timer_init failed ");

    /* init ipfix lib */
    if ( ipfix_init() < 0 ) {
        printf("\n ipfix_init() failed: %s\n", strerror(errno) );
        exit(1);
    }

    /* Load the FOKUS registered IEs */
    if ( ipfix_add_vendor_information_elements( ipfix_ft_fokus ) < 0 ) {
        printf("\n ipfix_add_ie() failed: %s\n", strerror(errno) );
        exit(1);
    }
    
    kafka_init();

    /* Reading netflow fields from json file */
    if ( JSON_parser( &nf_data, &match_field_count, &collect_field_count) < 0 )
        exit(1);

    /* signal handler */
    signal( SIGKILL, exit_func );
    signal( SIGTERM, exit_func );
    signal( SIGINT,  exit_func );
    signal( SIGALRM, create_buffer );
    signal( SIGUSR1, create_buffer ); // when the protobuf limit reached maximum, SIGUSR1 will invoke the create_buffer()

    /* initialization of ipfix collector */
    if( ipfix_collector_init() < 0 ){
        printf(" \n ipfix_col_init() failed .\n");
        exit(1);
    }

    /* open port for netflow packets */
    if ( ipfix_col_listen( &nudp_s1, &udp_s1, IPFIX_PROTO_UDP, 
                           NETFLOW_PORT, AF_INET, MAX_CONNECTION) < 0 ) {
        printf( "\n ipfix_listen(udp) failed.\n");
        return -1;
    }
    
    /* event loop for continuous run of program */
    (void) mpoll_loop( -1 );

    exit(1);
}

