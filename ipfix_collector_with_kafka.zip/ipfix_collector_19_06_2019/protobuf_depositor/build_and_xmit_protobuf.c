#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdbool.h>   
#include <pthread.h>
#include <curl/curl.h> 

#include "netflow.pb-c.h"
#include "build_and_xmit_protobuf.h"
#include "timer.h"
#include "rdkafka_simple_producer_test.h"

#define protobuf_limit 5  // 200 flows

#define INITIALIZED   1
#define UNINITIALIZED 0

/*------ global variable ---------------------------------------------------------*/

int protobuf_init_status = UNINITIALIZED; 

Netflow *netflow = NULL;  
FieldValues* f_values[protobuf_limit]; 

pthread_mutex_t lock;
int flow_count = 0;               
int msg = 0;
void *kafka_producer(void *buffer)
{
    printf("\nkafka_called\n");
    //uint8_t *buffer = (uint8_t*)args;
    //printf("%s\n",buffer);
    //printf("\nbuffer created\n");
    kafka_produce(buffer);
    free(buffer);
    return 0;
}

void create_buffer(int signo)
{
    void *tmp_buf;
    pthread_t t_id;
    size_t len;

    stop_timer();
    if(signo == SIGALRM){
        pthread_mutex_lock(&lock);
    }

    if(netflow == NULL){
        printf("\nNO FLOWS\n");
    }
    else{
        netflow->timestamp = "hello";//get_timestamp();
	netflow->n_f_values = flow_count;

        len = netflow__get_packed_size (netflow);
        //printf("\n%lu\n",len);
        //exit(1);
        tmp_buf = malloc(len);


        netflow__pack(netflow,tmp_buf);
        pthread_create(&t_id, NULL, kafka_producer, tmp_buf);
	    //kafka_producer(tmp_buf);
        netflow = NULL;
        flow_count = 0;
        protobuf_init_status = UNINITIALIZED;
    }
    //start_timer();
    pthread_mutex_unlock(&lock);
}

char *get_timestamp()
{
    time_t     now;
    struct tm  ts;
    char       *temp_buf;
    temp_buf = malloc(sizeof(char) * MAX_CHARACTERS);

    // Get current time
    time(&now);

    // Format time, "yyyy-mm-dd hh:mm:ss"
    ts = *localtime(&now);
    strftime(temp_buf, sizeof(temp_buf), "%Y-%m-%d %H:%M:%S", &ts);
    return temp_buf;
}



// Initialization of protobuf message structure with field names
int protobuf_init(collected_fields_and_values_t *col_data,int collected_field_count) 
{
    int i;
    netflow = malloc(sizeof(Netflow));
    netflow__init(netflow); 
    //printf("%p\n",netflow);

    // Add the required collect_field_name to the protobuf
    netflow->n_field_name = collected_field_count;
    netflow->field_name = malloc (sizeof (char *) * netflow->n_field_name); 
    for( i = 0; i < netflow->n_field_name ; i++) {
        netflow->field_name[i] = col_data->collected_field_names[i]; 
    }

    netflow->f_values   = f_values;
    start_timer();

    protobuf_init_status = INITIALIZED;
    return 0;
}

int build_protobuf(collected_fields_and_values_t *col_data,int collected_field_count) 
{
    int i;
    pthread_mutex_lock(&lock);


    if( protobuf_init_status == UNINITIALIZED ) {
        protobuf_init(col_data, collected_field_count);
    }
    
    f_values[flow_count] = malloc(sizeof(FieldValues));
    field_values__init(f_values[flow_count]);

    // Append the collected field values to the protobuf
    f_values[flow_count]->n_value = collected_field_count;
    f_values[flow_count]->value = malloc(sizeof(char *) * f_values[flow_count]->n_value);
    for(i = 0; i < f_values[flow_count]->n_value; i++){
        f_values[flow_count]->value[i] = col_data->collected_field_values[i];
    }

    flow_count++;

    //printf("Protobuf successfully built %d\n",flow_count);
    
    if( flow_count == protobuf_limit ) {
	    //msg++;
        raise(SIGUSR1);
	//kafka_stop();
	//kafka_init();
	/*if (msg == 100){
	    sleep(10);
	    kafka_stop();
	    exit(1);
	}*/
        return 0;
    }
    
    pthread_mutex_unlock(&lock);
    return 0;
}
