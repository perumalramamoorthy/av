
/* Timer functions */
void start_timer();
void stop_timer();
int timer_init();