int kafka_init();
int kafka_produce(uint8_t *);
void kafka_stop();
