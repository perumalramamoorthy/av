#define PORT 6000
#define LOCALHOST "192.168.0.116"

#define MAX_CHARACTERS 30
#define MAX_NO_OF_FIELDS_TO_MATCH 10
#define MAX_NO_OF_FIELDS_TO_COLLECT 20

typedef struct collected_fields_and_values{
    char collected_field_names[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
    char collected_field_values[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
}collected_fields_and_values_t;

/* Functions for building protobuf */
int protobuf_init(collected_fields_and_values_t * col_data, int collected_field_count);
int build_protobuf(collected_fields_and_values_t *, int);
char *get_timestamp();

/* Functions for sending http */
void *kafka_producer(void *args);
void create_buffer(int);
