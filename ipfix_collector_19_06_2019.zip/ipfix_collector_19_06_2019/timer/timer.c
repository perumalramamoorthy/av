#include <stdio.h>
#include <time.h>
#include <signal.h>

#include "build_and_xmit_protobuf.h"
#include "timer.h"

timer_t g_Timerid;

void start_timer()
{
	struct itimerspec value;
	value.it_value.tv_sec     = 10;   //Initially, waits for  120 seconds before sending SIGALRM
	value.it_value.tv_nsec    = 0;
	value.it_interval.tv_sec  = 10;   //sends SIGALRM every 120 seconds
	value.it_interval.tv_nsec = 0;

	timer_create (CLOCK_REALTIME, NULL, &g_Timerid);
	timer_settime (g_Timerid, 0, &value, NULL);
}

void stop_timer()
{
	struct itimerspec value;
	value.it_value.tv_sec     = 0;
	value.it_value.tv_nsec    = 0;
	value.it_interval.tv_sec  = 0;
	value.it_interval.tv_nsec = 0;

	timer_settime (g_Timerid, 0, &value, NULL);
}

int timer_init()
{
    (void) signal(SIGALRM, create_buffer); // SIGALRM will invoke the create_buffer function when timer expires
    start_timer();
    return 0;
}