#define BUFFER_SIZE 5000
#define MAX_TOKEN_COUNT 128

#define MAX_CHARACTERS 30
#define MAX_NO_OF_FIELDS_TO_MATCH 10
#define MAX_NO_OF_FIELDS_TO_COLLECT 20

#define TRUE  1
#define FALSE 0


typedef struct nf_data_to_match_and_collect{
	char netflow_field_name_to_match[MAX_NO_OF_FIELDS_TO_MATCH][MAX_CHARACTERS];
    int  netflow_field_number_to_match[MAX_NO_OF_FIELDS_TO_MATCH];
    char netflow_field_values_to_match[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
    char netflow_field_name_to_collect[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
    int  netflow_field_number_to_collect[MAX_NO_OF_FIELDS_TO_COLLECT];
}nf_data_to_match_and_collect_t;

/* Functions for parsing JSON file */
void readfile(char * , char * );

int IE_Name_to_Number_Conversion(char*);

int JSON_parser(nf_data_to_match_and_collect_t *,int*,int*);
