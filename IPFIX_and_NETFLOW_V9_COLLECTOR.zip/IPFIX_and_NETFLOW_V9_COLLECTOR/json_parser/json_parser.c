#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#include "ipfix_def.h"
#include "ipfix.h"
#include "jsmn.h"
#include "json_parser.h"


char *JSON_FILE_PATH = "./netflow_fields.json";

int  idx_1 = 0, idx_2 =0, idx_3 =0;
bool match_flag = 0,collect_flag = 0;

void readfile(char* filepath, char* fileContent)
{
	FILE *f;
	char c;
	int index;
	f = fopen( filepath, "rt" );
	while((c = fgetc(f)) != EOF) {
	    fileContent[index] = c;
	    index++;
	}
	fileContent[index] = '\0';
}

int IE_Name_to_Number_Conversion(char *IE_NAME)
{
	int ie_id, e_no, ret;
	ret = ipfix_get_eno_ieid( IE_NAME, &e_no, &ie_id); 
	
	if(ret == 0)
		return ie_id;
	else {
		printf("\n %s not found in IE list",IE_NAME);	
		exit(1);
	}

}

int JSON_parser(nf_data_to_match_and_collect_t *nf_data, int* match_field_count, int* collect_field_count)
{   

	char JSON_STRING[BUFFER_SIZE];
	char key[1024];
	char value[1024];

	int i;
	int total;

	jsmn_parser p;
	jsmntok_t t[MAX_TOKEN_COUNT];


	/* Check the existence of JSON file */
	if( access( JSON_FILE_PATH, F_OK ) < 0 ) {
		printf("\n JSON file %s parse error :  json file not found ", JSON_FILE_PATH);
    	return -1;
    }

	readfile(JSON_FILE_PATH, JSON_STRING);

    /* Initialize the json parser, jasmine */
	jsmn_init(&p);

	total = jsmn_parse(&p, JSON_STRING, strlen(JSON_STRING), t, sizeof(t)/(sizeof(t[0])));

	if (total < 0) {
    	printf("\n JSON file %s parse error :  Empty or invalid json file ", JSON_FILE_PATH);
  		return -1;
	}

	/* Assume the top-level element is an object */
	if (total < 1 || t[0].type != JSMN_OBJECT) {
  		printf("\n JSON file %s parse error :  Object expected ", JSON_FILE_PATH);
  		return -1;
	}

	/* Index 'i' is incremented by 2 to fetch subsequent key:value in key:value pairs */
	for (i = 1; i < total; i = i + 2 ) {

		jsmntok_t json_key = t[i];
		jsmntok_t json_value = t[i+1];

		int key_length = json_key.end - json_key.start;
		int string_length = json_value.end - json_value.start;
		int idx;
		
		for (idx = 0; idx < key_length; idx++) {
    		key[idx] = JSON_STRING[json_key.start + idx];
		}

		key[key_length] = '\0';
		if( 0 == strcmp(key, "netflow_fields_to_match") ) { //  "netflow_fields_to_match" matched successfully 
    		match_flag = TRUE;  
    		// when 'match' keyname matches, whole member list of 'key:value' pairs become the 
    		// value of the 'match' key. This would cause the 'key:value' pair member list of 
    		// 'match' key is not being processed individually. So, need to skip this 'value'
    		// and, go onto fetch the next 'key:value' pair to process the member list of 'match' key
    		continue;  
		}
		else if( 0 == strcmp(key, "netflow_fields_to_collect") ) { // "netflow_fields_to_collect" matched successfully 
    		collect_flag = TRUE;   
    		match_flag   = FALSE; 
    		// when 'collect' keyname matches, whole member list of 'key:value' pairs become the 
    		// value of the 'collect' key. This would cause the 'key:value' pair member list of 
    		// 'collect' key is not being processed individually. So, need to skip this 'value'
    		// and, go onto fetch the next 'key:value' pair to process the member list of 'collect' key
    		continue;   
		}
		

		for (idx = 0; idx < string_length; idx++) {
    		value[idx] = JSON_STRING[json_value.start + idx ];
		}

		value[string_length] = '\0';

		if( match_flag ) {
			strcpy( ( nf_data->netflow_field_name_to_match[idx_1] ), key );
			nf_data->netflow_field_number_to_match[idx_1++] = IE_Name_to_Number_Conversion(key);
			strcpy( ( nf_data->netflow_field_values_to_match[idx_2++] ), value );
			*(match_field_count) += 1;	
		}
		else if( collect_flag ) {
			strcpy( nf_data->netflow_field_name_to_collect[idx_3], key);
			nf_data->netflow_field_number_to_collect[idx_3++] = IE_Name_to_Number_Conversion(key);
			*(collect_field_count) += 1;
    		if( 0 != strcmp(value,"\0")) {
    			strcpy( nf_data->netflow_field_name_to_collect[idx_3], value);
       			nf_data->netflow_field_number_to_collect[idx_3++] = IE_Name_to_Number_Conversion(value);
       			*(collect_field_count) += 1;
       		}
		}
	}
	return 0;

}