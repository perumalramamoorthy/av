#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdbool.h>   
#include <pthread.h>
#include <curl/curl.h> 

#include "netflow.pb-c.h"
#include "build_and_xmit_protobuf.h"

/*------ global variable ---------------------------------------------------------*/
           

char *get_timestamp()
{
    time_t     now;
    struct tm  ts;
    char       *temp_buf;
    temp_buf = malloc(sizeof(char) * MAX_CHARACTERS);

    // Get current time
    time(&now);

    // Format time, "yyyy-mm-dd hh:mm:ss"
    ts = *localtime(&now);
    strftime(temp_buf, sizeof(temp_buf), "%Y-%m-%d %H:%M:%S", &ts);
    return temp_buf;
}




int build_protobuf(collected_fields_and_values_t *col_data,int collected_field_count) 
{
    int i;
    Netflow *msg; 
    msg = malloc(sizeof(Netflow));
    netflow__init(msg); 

    msg->timestamp = get_timestamp();
    msg->n_field_name  = collected_field_count;
    msg->field_name    = malloc (sizeof (char *) * msg->n_field_name); 
    msg->n_field_values = collected_field_count;
    msg->field_values   = malloc (sizeof (char *) * msg->n_field_values); 

    // Add the required collect_field_name and its value  to the protobuf
    for( i = 0; i < collected_field_count; i++) {
        msg->field_name[i]  =  col_data->collected_field_names[i]; 
        msg->field_values[i] =  col_data->collected_field_values[i];
    }

    /* PRINTING COLLECTED VALUES */
    for( i = 0; i < collected_field_count; i++) {
        printf("%s:%s\n",msg->field_name[i], msg->field_values[i]); 
    }

    printf(" Protobuf successfully built");

    return 0;
}
