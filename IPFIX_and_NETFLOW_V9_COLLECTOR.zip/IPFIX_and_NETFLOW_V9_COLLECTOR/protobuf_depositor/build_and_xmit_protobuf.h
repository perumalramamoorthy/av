
#define MAX_CHARACTERS 30
#define MAX_NO_OF_FIELDS_TO_MATCH 10
#define MAX_NO_OF_FIELDS_TO_COLLECT 20

typedef struct collected_fields_and_values{
    char collected_field_names[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
    char collected_field_values[MAX_NO_OF_FIELDS_TO_COLLECT][MAX_CHARACTERS];
}collected_fields_and_values_t;

/* Functions for building protobuf */
int build_protobuf(collected_fields_and_values_t *, int);
char *get_timestamp();
