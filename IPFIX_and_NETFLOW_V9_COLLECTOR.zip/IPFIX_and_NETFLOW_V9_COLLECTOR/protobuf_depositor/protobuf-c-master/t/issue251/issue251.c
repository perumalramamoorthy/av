#include <stdlib.h>

#include "t/issue251/issue251.pb-c.h"

int main(void)
{
	/*
	 * The problem in #251 caused invalid code to be generated in the
	 * .pb-c.h file, so there's nothing for us to do here.
	 */
	return EXIT_SUCCESS;
}
